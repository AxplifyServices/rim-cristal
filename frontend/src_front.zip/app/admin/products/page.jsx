'use client'

import AdminProducts from '../../../src/admin/views/AdminProducts'

export default function AdminProductsPage() {
  return <AdminProducts />
}